/**
 * @file tutoringRules.js
 * @module tutoringRules
 * @description Contains all client defined business rules for the typing tutor application.
 * @requires module:application.constants
 * @requires module:application.message.constants
 * @requires {@link https://www.npmjs.com/package/@haystacks/async|@haystacks/async}
 * @requires {@link https://www.npmjs.com/package/@haystacks/constants|@haystacks/constants}
 * @requires {@link https://www.npmjs.com/package/path|path}
 * @author Seth Hollingsead
 * @date 2023/02/23
 * @copyright Copyright © 2023-… by Seth Hollingsead. All rights reserved
 */

// Internal imports
// import * as apc from '../../constants/application.constants.js';
// import * as app_msg from '../../constants/application.message.constants.js';
// External imports
// import haystacks from '@haystacks/async';
// import hayConst from '@haystacks/constants';
// import path from 'path';

// const {bas, msg, wrd} = hayConst;
// const baseFileName = path.basename(import.meta.url, path.extname(import.meta.url));
// application.haystacks-tt.businessRules.clientRules.tutoringRules.
// const namespacePrefix = wrd.capplication + bas.cDot + apc.cApplicationName + bas.cDot + wrd.cbusiness + wrd.cRules + bas.cDot + wrd.cclient + wrd.cRules + bas.cDot + baseFileName + bas.cDot;

export default {

};