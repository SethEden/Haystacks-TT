/**
 * @file application.message.constants.js
 * @module application.message.constants
 * @description Contains many re-usable application message constants.
 * @requires module:application.command.constants
 * @requires module:application.configuration.constants
 * @requires module:application.constants
 * @requires module:application.system.constants
 * @requires {@link https://www.npmjs.com/package/@haystacks/constants|@haystacks/constants}
 * @author Seth Hollingsead
 * @date 2023/02/24
 * @copyright Copyright © 2023-… by Seth Hollingsead. All rights reserved
 */

// Internal Imports
import * as app_cmd from './application.command.constants.js';
import * as app_cfg from './application.configuration.constants.js';
import * as apc from './application.constants.js';
import * as app_sys from './application.system.constants.js';

// External imports
import hayConst from '@haystacks/constants';
const {bas, gen, msg, num, sys, wrd} = hayConst;

// General application messages
export const crawAccountDataIs = wrd.craw + wrd.cAccount + wrd.cData + sys.cSpaceIsColonSpace; // rawAccountData is:
export const crawLessonsDataIs = wrd.craw + wrd.cLessons + wrd.cData + sys.cSpaceIsColonSpace; // rawLessonsData is:
export const cuserAccountDataIs = wrd.cuser + wrd.cAccount + wrd.cData + sys.cSpaceIsColonSpace; // userAccountData is:
export const cuserAccountKeyIs = wrd.cuser + wrd.cAccount + wrd.cKey + sys.cSpaceIsColonSpace; // userAccountKey is:
export const cuserAccountIs = wrd.cuser + wrd.cAccount + sys.cSpaceIsColonSpace; // userAccount is:
export const caccountNameIs = wrd.caccount + wrd.cName + sys.cSpaceIsColonSpace; // accountName is:
export const clessonsDataIs = wrd.clessons + wrd.cData + sys.cSpaceIsColonSpace; // lessonsData is:
export const clessonKeyIs = wrd.clesson + wrd.cKey + sys.cSpaceIsColonSpace; // lessonKey is:
export const clessonDataIs = wrd.clesson + wrd.cData + sys.cSpaceIsColonSpace; // lessonData is:
export const clessonNameArrayIs = wrd.clesson + wrd.cName + wrd.cArray + sys.cSpaceIsColonSpace; // lessonNameArray is:
export const clessonNameIs = wrd.clesson + wrd.cName + sys.cSpaceIsColonSpace; // lessonName is:
export const cnewAccountIs = wrd.cnew + wrd.cAccount + sys.cSpaceIsColonSpace; // newAccount is:
export const cstoredAccountDataIs = wrd.cstored + wrd.cAccount + wrd.cData + sys.cSpaceIsColonSpace; // storedAccountData is:
export const cnewlyMergedAccountDataIs = wrd.cnewly + wrd.cMerged + wrd.cAccount + wrd.cData + sys.cSpaceIsColonSpace; // newlyMergedAccountData is:
export const cdataToStoreIs = wrd.cdata + wrd.cTo + wrd.cStore + sys.cSpaceIsColonSpace; // dataToStore is:
export const ccleanedAccountDataIs = wrd.ccleaned + wrd.cAccount + wrd.cData + sys.cSpaceIsColonSpace; // cleanedAccountData is:
export const cconfirmedDeleteUserResponseIs = wrd.cconfirmed + wrd.cDelete + wrd.cUser + wrd.cResponse + sys.cSpaceIsColonSpace; // confirmedDeleteUserResponse is:
export const callAccountsDataIs = wrd.call + wrd.cAccounts + wrd.cData + sys.cSpaceIsColonSpace; // allAccountsData is:
export const clessonNumberIs = wrd.clesson + wrd.cNumber + sys.cSpaceIsColonSpace; // lessonNumber is:
export const cindividualLessonDataIs = wrd.cindividual + wrd.cLesson + wrd.cData + sys.cSpaceIsColonSpace; // individualLessonData is:
export const cindividualLessonLineKeyIs = wrd.cindividual + wrd.cLesson + wrd.cLine + wrd.cKey + sys.cSpaceIsColonSpace; // individualLessonLineKey is:
export const cindividualLessonLineIs = wrd.cindividual + wrd.cLesson + wrd.cLine + sys.cSpaceIsColonSpace; // individualLessonLine is:
export const ccurrentUserNameIs = wrd.ccurrent + wrd.cUser + wrd.cName + sys.cSpaceIsColonSpace; // currentUserName is:
export const clessonPassingScoreEnabledIs = wrd.clesson + wrd.cPassing + wrd.cScore + wrd.cEnabled + sys.cSpaceIsColonSpace; // lessonPassingScoreEnabled is:
export const cpassingAccuracyScoreLimitIs = wrd.cpassing + wrd.cAccuracy + wrd.cScore + wrd.cLimit + sys.cSpaceIsColonSpace; // passingAccuracyScoreLimit is:
export const cpassingSpeedScoreLimitIs = wrd.cpassing + wrd.cSpeed + wrd.cScore + wrd.cLimit + sys.cSpaceIsColonSpace; // passingSpeedScoreLimit is:
export const clessonScoreDataIs = wrd.clesson + wrd.cScore + wrd.cData + sys.cSpaceIsColonSpace; // lessonScoreData is:
export const cmaxLessonNumberIs = wrd.cmax + wrd.cLesson + wrd.cNumber + sys.cSpaceIsColonSpace; // maxLessonNumber is:
export const cuserLessonNumberIs = wrd.cuser + wrd.cLesson + wrd.cNumber + sys.cSpaceIsColonSpace; // userLessonNumber is:
export const clessonAdvancementScoreLimitAccuracyIs = wrd.clesson + wrd.cAdvancement + wrd.cScore + wrd.cLimit + wrd.cAccuracy + sys.cSpaceIsColonSpace; // lessonAdvancementScoreLimitAccuracy is:
export const clessonAdvancementScoreLimitSpeedIs = wrd.clesson + wrd.cAdvancement + wrd.cScore + wrd.cLimit + wrd.cSpeed + sys.cSpaceIsColonSpace; // lessonAdvancementScoreLimitSpeed is:
export const cactualLessonDataIs = wrd.cactual + wrd.cLesson + wrd.cData + sys.cSpaceIsColonSpace; // actualLessonData is:
export const ccurrentLessonNumberIs = wrd.ccurrent + wrd.cLesson + wrd.cNumber + sys.cSpaceIsColonSpace; // currentLessonNumber is:
export const clessonDescriptionIs = wrd.clesson + wrd.cDescription + sys.cSpaceIsColonSpace; // lessonDescription is:
export const callLessonLinesIs = wrd.call + wrd.cLesson + wrd.cLines + sys.cSpaceIsColonSpace; // allLessonLines is:
export const callLessonLinesDataObjectIs = wrd.call + wrd.cLesson + wrd.cLines + wrd.cData + wrd.cObject + sys.cSpaceIsColonSpace; // allLessonLinesDataObject is:
export const clessonLineScoreDataIs = wrd.clesson + wrd.cLine + wrd.cScore + wrd.cData + sys.cSpaceIsColonSpace; // lessonLineScoreData is:
export const clessonLineStringIs = wrd.clesson + wrd.cLine + wrd.cString + sys.cSpaceIsColonSpace; // lessonLineString is:
export const cuserEnteredCharacterIs = wrd.cuser + wrd.cEntered + wrd.cCharacter + sys.cSpaceIsColonSpace; // userEnteredCharacter is:
export const clineStartTimeIs = wrd.cline + wrd.cStart + wrd.cTime + sys.cSpaceIsColonSpace; // lineStartTime is:
export const clineEndTimeIs = wrd.cline + wrd.cEnd + wrd.cTime + sys.cSpaceIsColonSpace; // lineEndTime is:
export const ccharactersCorrectCountIs = wrd.ccharacters + wrd.cCorrect + wrd.cCount + sys.cSpaceIsColonSpace; // charactersCorrectCount is:
export const ccharactersInCorrectCountIs = wrd.ccharacters + wrd.cIncorrect + wrd.cCount + sys.cSpaceIsColonSpace; // charactersIncorrectCount is:
export const ctotalNumberOfWordsIs = wrd.ctotal + wrd.cNumber + wrd.cOf + wrd.cWords + sys.cSpaceIsColonSpace; // totalNumberOfWords is:
export const cwpmIs = gen.cwpm + sys.cSpaceIsColonSpace; // wpm is:
export const cwpmSumIs = gen.cwpm + wrd.cSum + sys.cSpaceIsColonSpace; // wpmSum is:
export const caccuracyIs = wrd.caccuracy + sys.cSpaceIsColonSpace; // accuracy is:
export const caccuracySumIs = wrd.caccuracy + wrd.cSum + sys.cSpaceIsColonSpace; // accuracySum is:
export const cscoresDataArrayIs = wrd.cscores + wrd.cData + wrd.cArray + sys.cSpaceIsColonSpace; // scoresDataArray is:
export const cscoresDataArrayLengthIs = wrd.cscores + wrd.cData + wrd.cArray + bas.cDot + wrd.clength + sys.cSpaceIsColonSpace; // scoresDataArray.length is:
export const cscoreObjectIs = wrd.cscore + wrd.cObject + sys.cSpaceIsColonSpace; // scoreObject is:
export const clessonTimeStampIs = wrd.clesson + wrd.cTime + wrd.cStamp + sys.cSpaceIsColonSpace; // lessonTimeStamp is:
export const ctotalTimeIs = wrd.ctotal + wrd.cTime + sys.cSpaceIsColonSpace; // totalTime is:
export const ctotalCorrectCharacterCountIs = wrd.ctotal + wrd.cCorrect + wrd.cCharacter + wrd.cCount + sys.cSpaceIsColonSpace; // totalCorrectCharacterCount is:
export const ctotalIncorrectCharacterCountIs = wrd.ctotal + wrd.cIncorrect + wrd.cCharacter + wrd.cCount + sys.cSpaceIsColonSpace; // totalIncorrectCharacterCount is:
export const ctotalWordsIs = wrd.ctotal + wrd.cWords + sys.cSpaceIsColonSpace; // totalWords is:
export const caverageWpmIs = wrd.caverage + gen.cWPM + sys.cSpaceIsColonSpace; // averageWPM is:
export const caverageAccuracyIs = wrd.caverage + wrd.cAccuracy + sys.cSpaceIsColonSpace; // averageAccuracy is:
export const cupdatedUserAccountDataIs = wrd.cupdated + wrd.cUser + wrd.cAccount + wrd.cData + sys.cSpaceIsColonSpace; // updatedUserAccountData is:
export const cdataToAppendIs = wrd.cdata + wrd.cTo + wrd.cAppend + sys.cSpaceIsColonSpace; // dataToAppend is:
export const ccurrentUserAccountNameIs = wrd.ccurrent + wrd.cUser + wrd.cAccount + wrd.cName + sys.cSpaceIsColonSpace; // currentUserAccountName is:
export const clessonNameKeyIs = wrd.clesson + wrd.cName + wrd.cKey + sys.cSpaceIsColonSpace; // lessonNameKey is:
export const cusersLessonDataObjectIs = wrd.cusers + wrd.cLesson + wrd.cData + wrd.cObject + sys.cSpaceIsColonSpace; // usersLessonDataObject is:
export const cusersLessonDataObjectKeysIs = wrd.cusers + wrd.cLesson + wrd.cData + wrd.cObject + wrd.cKeys + sys.cSpaceIsColonSpace; // usersLessonDataObjectKeys is: 
export const cusersLessonDataIs = wrd.cusers + wrd.cLesson + wrd.cData + sys.cSpaceIsColonSpace; // usersLessonData is:
export const cusersLessonDataAfterPushIs = wrd.cusers + wrd.cLesson + wrd.cData + bas.cSpace + wrd.cafter + bas.cSpace + wrd.cdata + bas.cSpace + wrd.cpush + sys.cSpaceIsColonSpace; // usersLessonData after data push is:
export const clessonNameKeyEqualsLessonName = wrd.clesson + wrd.cName + wrd.cKey + bas.cSpace + bas.cEqualEqualEqual + bas.cSpace + wrd.clesson + wrd.cName; // lessonNameKey === lessonName
export const cappAccountsPathIs = wrd.capp + wrd.cAccounts + wrd.cPath + sys.cSpaceIsColonSpace; // appAccountsPath is:
export const cadvancementLimitSettingIs = wrd.cadvancement + wrd.cLimit + wrd.cSetting + sys.cSpaceIsColonSpace; // advancementLimitSetting is:
export const cindividualizedLessonSettingIs = wrd.cindividualized + wrd.cLesson + wrd.cSetting + sys.cSpaceIsColonSpace; // individualizedLessonSetting is:
export const callLessonsDataIs = wrd.call + wrd.cLessons + wrd.cData + sys.cSpaceIsColonSpace; // allLessonsData is:
export const clessonPlanKeysIs = wrd.clesson + wrd.cPlan + wrd.cKeys + sys.cSpaceIsColonSpace; // lessonPlanKeys is:
export const clessonKeyValueIs = wrd.clesson + wrd.cKey + wrd.cValue + sys.cSpaceIsColonSpace; // lessonKeyValue is:
export const cadjustedWpmIs = wrd.cadjusted + gen.cWpm + sys.cSpaceIsColonSpace; // adjustedWpm is:
export const clessonCountIs = wrd.clesson + wrd.cCount + sys.cSpaceIsColonSpace; // lessonCount is:
export const chighestScoringLessonAboveAdvancementLimitIs = wrd.chighest + wrd.cScoring + wrd.cLesson + wrd.cAbove + wrd.cAdvancement + wrd.cLimit + sys.cSpaceIsColonSpace; // highestScoringLessonAboveAdvancementLimit is:
export const cmasterLessonsData = wrd.cmaster + wrd.cLessons + wrd.cData + sys.cSpaceIsColonSpace; // masterLessonsData is:
export const chighestScoreForLessonIs = wrd.chighest + wrd.cScore + wrd.cFor + wrd.cLesson + sys.cSpaceIsColonSpace; // highestScoreForLesson is:
export const cindividualLessonNameIs = wrd.cindividual + wrd.cLesson + wrd.cName + sys.cSpaceIsColonSpace; // individualLessonName is:
export const cusersLessonScoreIndividualLessonRecordIs = wrd.cusers + wrd.cLesson + wrd.cScore + wrd.cIndividual + wrd.cLesson + wrd.cRecord + sys.cSpaceIsColonSpace; // usersLessonScoreIndividualLessonRecord is:
export const caccuracyLimitIs = wrd.caccuracy + wrd.cLimit + sys.cSpaceIsColonSpace; // accuracyLimit is:
export const cspeedLimitIs = wrd.cspeed + wrd.cLimit + sys.cSpaceIsColonSpace; // speedLimit is:
export const cinputUserNameIs = wrd.cinput + wrd.cUser + wrd.cName + sys.cSpaceIsColonSpace; // inputUserName is:
export const cdesiredCurriculumIs = wrd.cdesired + wrd.cCurriculum + sys.cSpaceIsColonSpace; // desiredCurriculum is:
export const ccurrentCurriculumIndexIs = wrd.ccurrent + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // CurrentCurriculumIndex is:
export const cnewCurrentCurriculumIndexIs = wrd.cnew + wrd.cCurrent + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // newCurrentCurriculumIndex is:
export const cstringSettingValueIs = wrd.cstring + wrd.cSetting + wrd.cValue + sys.cSpaceIsColonSpace; // stringSettingValue is:
export const cnewSettingValueIs = wrd.cnew + wrd.cSetting + wrd.cValue + sys.cSpaceIsColonSpace; // newSettingValue is:
export const csettingSavedIs = wrd.csetting + wrd.cSaved + sys.cSpaceIsColonSpace; // settingSaved is:
export const ccurriculumIndexIs = wrd.ccurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // curriculumIndex is:
export const cuserName = wrd.cuser + wrd.cName; // userName
export const cuserNameIs = cuserName + sys.cSpaceIsColonSpace; // userName is:
export const cuserName1Is = cuserName + num.c1 + sys.cSpaceIsColonSpace; // userName1 is:
export const cuserName2Is = cuserName + num.c2 + sys.cSpaceIsColonSpace; // userName2 is:
export const cuserDataIs = wrd.cuser + wrd.cData + sys.cSpaceIsColonSpace; // userData is:
export const cuserData1Is = wrd.cuser + wrd.cData + num.c1 + sys.cSpaceIsColonSpace; // userData1 is:
export const cuserData2Is = wrd.cuser + wrd.cData + num.c2 + sys.cSpaceIsColonSpace; // userData2 is:
export const ccurriculumDataIs = wrd.ccurriculum + wrd.cData + sys.cSpaceIsColonSpace; // curriculumData is:
export const ccurrentCurriculumDataIs = wrd.ccurrent + wrd.cCurriculum + wrd.cData + sys.cSpaceIsColonSpace; // currentCurriculumData is:
export const coptionalCurriculumIndexIs = wrd.coptional + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // optionalCurriculumIndex is:
export const cuserHasCurriculumIndexIs = wrd.cuser + wrd.cHas + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // userHasCurriculumIndex is:
export const clessonsIs = wrd.clessons + sys.cSpaceIsColonSpace; // lessons is:
export const cexistingLessonNameIs = wrd.cexisting + wrd.cLesson + wrd.cName + sys.cSpaceIsColonSpace// existingLessonName is:
export const ccurriculumNameIs = wrd.ccurriculum + wrd.cName + sys.cSpaceIsColonSpace; // curriculumName is:
export const ccurrentUserIs = wrd.ccurrent + wrd.cUser + sys.cSpaceIsColonSpace; // currentUser is:
export const cadhereToCurriculumOrderRequirementIs = wrd.cadhere + wrd.cTo + wrd.cCurriculum + wrd.cOrder + wrd.cRequirement + sys.cSpaceIsColonSpace; // adhereToCurriculumOrderRequirement is:
export const cfullyQualifiedCurriculumIndexIs = wrd.cfully + wrd.cQualified + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // fullyQualifiedCurriculumIndex is:
export const cfullyQualifiedCurriculumNameIs = wrd.cfully + wrd.cQualified + wrd.cCurriculum + wrd.cName + sys.cSpaceIsColonSpace; // fullyQualifiedCurriculumName is:
export const clistOfCurrentCurriculumPrerequisitesIs = wrd.clist + wrd.cOf + wrd.cCurrent + wrd.cCurriculum + wrd.cPrerequisites + sys.cSpaceIsColonSpace; // listOfCurrentCurriculumPrerequisites is:
export const clistOfCurrentCurriculumPrerequisitesLengthIs = wrd.clist + wrd.cOf + wrd.cCurrent + wrd.cCurriculum + wrd.cPrerequisites + bas.cDot + wrd.clength + sys.cSpaceIsColonSpace; // listOfCurrentCurriculumPrerequisites.length is:
export const cverifyCurriculumIndexIs = wrd.cverify + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // verifyCurriculumIndex is:
export const cdataParsedVerifyCurriculumIndexIs = wrd.cdata + wrd.cParsed + wrd.cVerify + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // dataParsedVerifyCurriculumIndex is:
export const chighestLessonForCurriculumIs = wrd.chighest + wrd.cLesson + wrd.cFor + wrd.cCurriculum + sys.cSpaceIsColonSpace; // highestLessonForCurriculum is:
export const cuserHighestPassingLessonNumberByCurriculumIndexIs = wrd.cuser + wrd.cHighest + wrd.cPassing + wrd.cLesson + wrd.cNumber + wrd.cBy + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // userHighestPassingLessonNumberByCurriculumIndex is:
export const ccurriculumSearchTermIs = wrd.ccurriculum + wrd.cSearch + wrd.cTerm + sys.cSpaceIsColonSpace; // curriculumSearchTerm is:
export const callCurriculumNamesIs = wrd.call + wrd.cCurriculum + wrd.cNames + sys.cSpaceIsColonSpace; // allCurriculumNames is:
export const callCurriculumIndicesIs = wrd.call + wrd.cCurriculum + wrd.cIndices + sys.cSpaceIsColonSpace; // allCurriculumIndices is:
export const cisIntegerResultIs = wrd.cis + wrd.cInteger + wrd.cResult + sys.cSpaceIsColonSpace; // isIntegerResult is:
export const cparsedCurriculumSearchTermIs = wrd.cparsed + wrd.cCurriculum + wrd.cSearch + wrd.cTerm + sys.cSpaceIsColonSpace; // parsedCurriculumSearchTerm is:
export const ccurriculumLookupIndexIs = wrd.ccurriculum + wrd.cLookup + wrd.cIndex + sys.cSpaceIsColonSpace; // curriculumLookupIndex is:
export const cindexedCurriculumObjectIs = wrd.cindexed + wrd.cCurriculum + wrd.cObject + sys.cSpaceIsColonSpace; // indexedCurriculumObject is:
export const cparsedCurriculumIndexIs = wrd.cparsed + wrd.cCurriculum + wrd.cIndex + sys.cSpaceIsColonSpace; // parsedCurriculumIndex is:
export const clistOfCurriculumIndicesIs = wrd.clist + wrd.cOf + wrd.cCurriculum + wrd.cIndices + sys.cSpaceIsColonSpace; // listOfCurriculumIndices is:
export const clessonObjectIs = wrd.clesson + wrd.cObject + sys.cSpaceIsColonSpace; // lessonObject is:
export const cusersLessonDataValue = wrd.cusers + wrd.cLesson + wrd.cData + wrd.cValue + sys.cSpaceIsColonSpace; // usersLessonDataValue is:
export const ccurrentMaxScore = wrd.ccurrent + wrd.cMax + wrd.cScore + sys.cSpaceIsColonSpace; // currentMaxScore is:
export const cindexOfMaxScore = wrd.cindex + wrd.cOf + wrd.cMax + wrd.cScore + sys.cSpaceIsColonSpace; // indexOfMaxScore is:
export const callAccountUserNamesIs = wrd.call + wrd.cAccount + wrd.cUser + wrd.cNames + sys.cSpaceIsColonSpace; // allAccountUserNames is:
export const ccurrentUserNameKeyIs = wrd.ccurrent + wrd.cUser + wrd.cName + wrd.cKey + sys.cSpaceIsColonSpace; // currentUserNameKey is:

// Application messages
export const cinstructionsMessage00 = wrd.cInstructions + bas.cSpace + wrd.cto + bas.cSpace + wrd.cend + bas.cSpace + wrd.cuser + bas.cColon; // Instructions to end user:
export const cinstructionsMessage01 = wrd.cCreate + bas.cSpace + wrd.can + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cusing + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ccreate + wrd.cAccount + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cand + bas.cSpace + wrd.cprovide + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cuser + wrd.cname + bas.cDot; // Create an account using the createAccount command and provide your username.
export const cinstructionsMessage02 = wrd.cUse + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clogin + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cto + bas.cSpace + wrd.clogin + bas.cSpace + wrd.cto + bas.cSpace + wrd.cyour + bas.cSpace + wrd.caccount + bas.cComa + bas.cSpace + wrd.cno + bas.cSpace + wrd.cpassword + bas.cSpace + wrd.cor + bas.cSpace + wrd.cemail + bas.cSpace + wrd.crequired + bas.cDot; // Use the login command to login to your account, no password or email required.
export const cinstructionsMessage03 = wrd.cUse + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clogout + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cto + bas.cSpace + wrd.clogout + bas.cComa + bas.cSpace + wrd.cif + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cwant + bas.cSpace + wrd.cto + bas.cSpace + wrd.callow + bas.cSpace + wrd.canother + bas.cSpace + wrd.cuser + bas.cSpace + wrd.cto + bas.cSpace + wrd.clogin + bas.cComa + bas.cSpace + wrd.cor + bas.cSpace + wrd.cjust + bas.cSpace + wrd.cexit + bas.cSpace + wrd.cby + bas.cSpace + wrd.ctyping + bas.cSpace + wrd.cexit + bas.cForwardSlash + wrd.cquit + bas.cSpace + wrd.cor + bas.cSpace + bas.cx + bas.cForwardSlash + bas.cq + bas.cDot; // Use the logout command to logout, if you want to allow another user to login, or just exit by typing exit/quit or x/q.
export const cinstructionsMessage04 = wrd.cAll + bas.cSpace + wrd.cyour + bas.cSpace + wrd.clesson + bas.cSpace + wrd.crecords + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cbe + bas.cSpace + wrd.cstored + bas.cSpace + wrd.cunder + bas.cSpace + wrd.cyour + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cname + bas.cSpace + wrd.cin + bas.cSpace + bas.ca + bas.cSpace + wrd.clocal + bas.cSpace + wrd.cfile + bas.cSpace + wrd.cunder + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cresources + bas.cSpace + wrd.cfolder + bas.cDot; // All your lesson records will be stored under your account name in a local file under the resources folder.
export const cinstructionsMessage05 = wrd.cYou + bas.cSpace + wrd.ccan + bas.cSpace + wrd.copt + bas.cDash + wrd.cout + bas.cSpace + wrd.cof + bas.cSpace + wrd.csaving + bas.cSpace + wrd.cyour + bas.cSpace + wrd.crecords + bas.cSpace + wrd.cby + bas.cSpace + wrd.cchanging + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cflag + bas.cColon + bas.cSpace + app_cfg.csaveTypingRecords + bas.cSpace + wrd.cin + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cconfiguration + bas.cSpace + wrd.csettings + bas.cSpace + wrd.cfile + bas.cColon + bas.cSpace + bas.cDot + bas.cForwardSlash + wrd.csrc + bas.cForwardSlash + wrd.cresources + bas.cForwardSlash + wrd.cconfiguration + bas.cForwardSlash + wrd.capplication + bas.cDot + wrd.csystem + gen.cDotjson; // You can opt-out of saving your records by changing the flag: saveTypingRecords in the configuration settings file: ./src/resources/configuration/application.system.json
export const cinstructionsMessage06 = wrd.cYou + bas.cSpace + wrd.ccan + bas.cSpace + wrd.ccall + bas.cSpace + app_cmd.cdestroyRecords + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cwith + bas.cSpace + wrd.cyour + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cname + bas.cSpace + wrd.cto + bas.cSpace + wrd.cwipe + bas.cSpace + wrd.cout + bas.cSpace + wrd.cyour + bas.cSpace + wrd.ctyping + bas.cSpace + wrd.crecords + bas.cSpace + wrd.cfor + bas.cSpace + wrd.cgood + bas.cDot; // You can call destroyRecords command with your account name to wipe out your typing records for good.
export const cinstructionsMessage07 = wrd.cThe + bas.cSpace + app_cmd.cdeleteAccount + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cdelete + bas.cSpace + wrd.cyour + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cand + bas.cSpace + wrd.cdestroy + bas.cSpace + wrd.call + bas.cSpace + wrd.cyour + bas.cSpace + wrd.ctyping + bas.cSpace + wrd.crecords + bas.cSpace + wrd.cfor + bas.cSpace + wrd.cgood + bas.cDot; // The deleteAccount command will delete your account and destroy all your typing records for good.
export const cinstructionsMessage08 = wrd.cOnce + bas.cSpace + wrd.cyou + bas.cSpace + wrd.care + bas.cSpace + wrd.clogged + bas.cSpace + wrd.cin + bas.cComa + bas.cSpace + wrd.cyou + bas.cSpace + wrd.ccan + bas.cSpace + wrd.cuse + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clessons + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cto + bas.cSpace + wrd.cdisplay + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cand + bas.cSpace + wrd.csee + bas.cSpace + wrd.cwhich + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cyou + bas.cSpace + wrd.chave + bas.cSpace + wrd.ccompleted + bas.cComa + bas.cSpace + wrd.cand + bas.cSpace + wrd.cwhich + bas.cSpace + num.cones + bas.cSpace + wrd.care + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cyet + bas.cSpace + wrd.cstarted + bas.cDot; // Once you are logged in, you can use the lessons command to display the lessons and see which lessons you have completed, and which ones are not yet started.
export const cinstructionsMessage09 = wrd.cIf + bas.cSpace + wrd.cyou + bas.cSpace + wrd.care + bas.cSpace + wrd.cNOT + bas.cSpace + wrd.clogged + bas.cSpace + wrd.cin + bas.cComa + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clessons + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cwill + bas.cSpace + wrd.csimply + bas.cSpace + wrd.clist + bas.cSpace + wrd.call + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cavailable + bas.cSpace + wrd.cby + bas.cSpace + wrd.cthe + bas.cSpace + wrd.csystem + bas.cDot; // If you are NOT logged in, the lessons command will simply list all the lessons available by the system.
export const cinstructionsMessage10 = wrd.cIf + bas.cSpace + wrd.cyou + bas.cSpace + wrd.care + bas.cSpace + wrd.cNOT + bas.cSpace + wrd.clogged + bas.cSpace + wrd.cin + bas.cComa + bas.cSpace + wrd.crunning + bas.cSpace + wrd.cthe + bas.cSpace + app_cmd.cstartLesson + bas.cSpace + wrd.cwith + bas.cSpace + bas.ca + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cstart + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cwithout + bas.cSpace + wrd.csaving + bas.cSpace + wrd.cany + bas.cSpace + wrd.cof + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ctyping + bas.cSpace + wrd.crecords + bas.cDot; // If you are NOT logged in, running the startLesson with a lesson number will start the lesson without saving any of the typing records.
export const cinstructionsMessage11 = wrd.cIf + bas.cSpace + wrd.cyou + bas.cSpace + wrd.care + bas.cSpace + wrd.clogged + bas.cSpace + wrd.cin + bas.cSpace + wrd.cthe + bas.cSpace + wrd.csystem + bas.cSpace + wrd.cwill + bas.cSpace + wrd.conly + bas.cSpace + wrd.clet + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cproceed + bas.cSpace + wrd.cto + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cnext + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cif + bas.cSpace + wrd.cyou + bas.cSpace + wrd.chave + bas.cSpace + wrd.ccompleted + bas.cSpace + wrd.call + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cprevious + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cwith + bas.cSpace + num.c90 + bas.cPercent + bas.cSpace + wrd.csuccess + bas.cSpace + wrd.cor + bas.cSpace + wrd.cgreater + bas.cDot; // If you are logged in the system will only let you proceed to the next lesson if you have completed all the previous lessons with 90% success or greater.
export const cinstructionsMessage12 = wrd.cYou + bas.cSpace + wrd.ccan + bas.cSpace + wrd.cchange + bas.cSpace + wrd.cthe + bas.cSpace + wrd.csuccess + bas.cSpace + wrd.climiting + bas.cSpace + wrd.cfactor + bas.cSpace + wrd.cby + bas.cSpace + wrd.cchanging + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cconfiguration + bas.cSpace + wrd.cflags + bas.cColon + bas.cSpace + app_cfg.clessonPlanSuccessLimitingAccuracy + bas.cComa + bas.cSpace + app_cfg.clessonPlanSuccessLimitingSpeed + bas.cSpace + wrd.cto + bas.cSpace + wrd.csome + bas.cSpace + wrd.cother + bas.cSpace + wrd.cvalue + bas.cSpace + wrd.cother + bas.cSpace + wrd.cthan + bas.cSpace + num.c90 + bas.cPercent + bas.cComa + bas.cSpace + num.c70 + gen.cwpm + bas.cDot; // You can change the success limiting factor by changing the configuration flags: lessonPlanSuccessLimitingAccuracy, lessonPlanSuccessLimitingSpeed to some other value other than 90%, 70wpm.
export const cinstructionsMessage13 = wrd.cYou + bas.cSpace + wrd.ccan + bas.cSpace + wrd.cdisable + bas.cSpace + wrd.cthe + bas.cSpace + wrd.csuccess + bas.cSpace + wrd.climiting + bas.cSpace + wrd.cfactor + bas.cSpace + wrd.ccompletely + bas.cSpace + wrd.cand + bas.cSpace + wrd.callow + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cusers + bas.cSpace + wrd.cto + bas.cSpace + wrd.ctake + bas.cSpace + wrd.cany + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cat + bas.cSpace + wrd.cany + bas.cSpace + wrd.ctime + bas.cSpace + wrd.cby + bas.cSpace + wrd.cchanging + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cconfiguration + bas.cSpace + wrd.cflag + bas.cColon + bas.cSpace + app_cfg.cenableLessonPlanLimitingFactors + bas.cDot; // You can disable the success limiting factor completely and allow your users to take any lesson at any time by changing the configuration flag: enableLessonPlanLimitingFactors.
export const cinstructionsMessage14 = wrd.cEnter + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.capp + bas.cQuestion + bas.cForwardSlash + wrd.capp + wrd.cHelp + bas.cSpace + wrd.cor + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cinstructions + bas.cSpace + wrd.cto + bas.cSpace + wrd.cdisplay + bas.cSpace + wrd.cthese + bas.cSpace + wrd.cinstructions + bas.cSpace + wrd.cagain + bas.cDot; // Enter the command app?/appHelp or the command instructions to display these instructions again.

// ERROR: Invalid user name, please try again with a valid username.
export const cErrorInvalidUserNameCreateAccountMessage01 = msg.cERROR_Colon + wrd.cInvalid + bas.cSpace + wrd.cuser + bas.cSpace + wrd.cname + bas.cComa + bas.cSpace + wrd.cplease + bas.cSpace + wrd.ctry + bas.cSpace + wrd.cagain + bas.cSpace + wrd.cwith + bas.cSpace + bas.ca + bas.cSpace + wrd.cvalid + bas.cSpace + wrd.cuser + wrd.cname + bas.cDot;
// ERROR: The user account already exists, please choose a different user name and try again.
export const cErrorInvalidUserNameCreateAccountMessage02 = msg.cERROR_Colon + wrd.cThe + bas.cSpace + wrd.cuser + bas.cSpace + wrd.caccount + bas.cSpace + wrd.calready + bas.cSpace + wrd.cexists + bas.cComa + bas.cSpace + wrd.cplease + bas.cSpace + wrd.cchoose + bas.cSpace + bas.ca + bas.cSpace + wrd.cdifferent + bas.cSpace + wrd.cuser + bas.cSpace + wrd.cname + bas.cSpace + wrd.cand + bas.cSpace + wrd.ctry + bas.cSpace + wrd.cagain + bas.cDot
// ERROR: Newly created account was not saved, could not create the specified account:
export const cErrorCreateAccountMessage02 = msg.cERROR_Colon + wrd.cNewly + bas.cSpace + wrd.ccreated + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cwas + bas.cSpace + wrd.cnot + bas.cSpace + wrd.csaved + bas.cComa + bas.cSpace + wrd.ccould + bas.cSpace + wrd.cnot + bas.cSpace + wrd.ccreate + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cspecified + bas.cSpace + wrd.caccount + bas.cColon + bas.cSpace;
// ERROR: No user accounts data was loaded, please ensure the accounts resources folder has accounts data. Path:
export const cErrorNoUserAccountsDataLoadedMessage01 = msg.cERROR_Colon + wrd.cNo + bas.cSpace + wrd.cuser + bas.cSpace + wrd.caccounts + bas.cSpace + wrd.cdata + bas.cSpace + wrd.cwas + bas.cSpace + wrd.cloaded + bas.cComa + bas.cSpace + wrd.cplease + bas.cSpace + wrd.censure + bas.cSpace + wrd.cthe + bas.cSpace + wrd.caccounts + bas.cSpace + wrd.cresources + bas.cSpace + wrd.cfolder + bas.cSpace + wrd.chas + bas.cSpace + wrd.caccounts + bas.cSpace + wrd.cdata + bas.cDot + bas.cSpace + wrd.cPath + bas.cColon + bas.cSpace;
// ERROR: No typing lessons data was loaded, please ensure the lessons folder has lessons data. Path:
export const cErrorNoLessonDataLoadedMessage01 = msg.cERROR_Colon + wrd.cNo + bas.cSpace + wrd.ctyping + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cdata + bas.cSpace + wrd.cwas + bas.cSpace + wrd.cloaded + bas.cComa + bas.cSpace + wrd.cplease + bas.cSpace + wrd.censure + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cfolder + bas.cSpace + wrd.chas + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cdata + bas.cDot + bas.cSpace + wrd.cPath + bas.cColon + bas.cSpace;
// ERROR: Cannot delete user, user does not exist.
export const cErrorNoUserFoundDeleteAccountMessage01 = msg.cERROR_Colon + wrd.cCannot + bas.cSpace + wrd.cdelete + bas.cSpace + wrd.cuser + bas.cComa + bas.cSpace + wrd.cuser + bas.cSpace + wrd.cdoes + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cexist + bas.cDot;
// INFO: No account was deleted.
export const cErrorNoDeleteAccountMessage02 = wrd.cINFO + bas.cColon + bas.cSpace + wrd.cNo + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cwas + bas.cSpace + wrd.cdeleted + bas.cDot;
// WARNING: All user account data will be lost FOREVER!
export const cUserDeleteAccountConfirmedMessage01 = msg.cWARNING_Colon + wrd.cAll + bas.cSpace + wrd.cuser + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cdata + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cbe + bas.cSpace + wrd.clost + bas.cSpace + wrd.cFOREVER + bas.cExclamation;
// Are you sure you want to delete the account? (yes/y or no/n)
export const cUserDeleteAccountConfirmedMessage02 = wrd.cAre + bas.cSpace + wrd.cyou + bas.cSpace + wrd.csure + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cwant + bas.cSpace + wrd.cto + bas.cSpace + wrd.cdelete + bas.cSpace + wrd.cthe + bas.cSpace + wrd.caccount + bas.cQuestion + bas.cSpace + bas.cOpenParenthesis + wrd.cyes + bas.cForwardSlash + bas.cy + bas.cSpace + wrd.cor + bas.cSpace + wrd.cno + bas.cForwardSlash + bas.cn + bas.cCloseParenthesis;
// ERROR: Cannot login, user does not exist.
export const cErrorNoUserFoundLoginMessage01 = msg.cERROR_Colon + wrd.cCannot + bas.cSpace + wrd.clogin + bas.cComa + bas.cSpace + wrd.cuser + bas.cSpace + wrd.cdoes + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cexist + bas.cDot;
// ERROR: Unable to login with the specified user:
export const cErrorLoginMessage02 = msg.cERROR_Colon + wrd.cUnable + bas.cSpace + wrd.cto + bas.cSpace + wrd.clogin + bas.cSpace + wrd.cwith + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cspecified + bas.cSpace + wrd.cuser + bas.cColon + bas.cSpace;
// ERROR: Failure to logout.
export const cErrorFailureToLogOutMessage01 = msg.cERROR_Colon + wrd.cFailure + bas.cSpace + wrd.cto + bas.cSpace + wrd.clogout + bas.cDot;
// ERROR: No lesson number entered. Please enter a valid lesson number to execute.
export const cErrorStartLessonMessage01 = msg.cERROR_Colon + wrd.cNo + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cSpace + wrd.centered + bas.cDot + bas.cSpace + wrd.cPlease + bas.cSpace + wrd.center + bas.cSpace + bas.ca + bas.cSpace + wrd.cvalid + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cSpace + wrd.cto + bas.cSpace + wrd.cexecute + bas.cDot;
// ERROR: Invalid lesson number entered. Please enter a valid lesson number to execute.
export const cErrorStartLessonMessage02 = msg.cERROR_Colon + wrd.cInvalid + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cSpace + wrd.centered + bas.cDot + bas.cSpace + wrd.cPlease + bas.cSpace + wrd.center + bas.cSpace + bas.ca + bas.cSpace + wrd.cvalid + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cSpace + wrd.cto + bas.cSpace + wrd.cexecute + bas.cDot;
// ERROR: The lesson number entered is not available.
export const cErrorStartLessonMessage03 = msg.cERROR_Colon + wrd.cThe + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cSpace + wrd.centered + bas.cSpace + wrd.cis + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cavailable + bas.cDot;
// Please enter a lesson number between 1 and:
export const cErrorStartLessonMessage04 = wrd.cPlease + bas.cSpace + wrd.center + bas.cSpace + bas.ca + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cSpace + wrd.cbetween + bas.cSpace + num.c1 + bas.cSpace + wrd.cand + bas.cColon + bas.cSpace;
// ERROR: There was an error with the lesson data, invalid lesson number: 
export const cErrorGetIndividualLessonDataMessage01 = msg.cERROR_Colon + wrd.cThere + bas.cSpace + wrd.cwas + bas.cSpace + wrd.can + bas.cSpace + wrd.cerror + bas.cSpace + wrd.cwith + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cdata + bas.cComa + bas.cSpace + wrd.cinvalid + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cColon + bas.cSpace;
// ERROR: No lesson lines for the specified lesson number:
export const cErrorExecuteLessonMessage01 = msg.cERROR_Colon + wrd.cNo + bas.cSpace + wrd.clesson + bas.cSpace + wrd.clines + bas.cSpace + wrd.cfor + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cspecified + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cnumber + bas.cColon + bas.cSpace;
export const csaveAccountDataFailureMessage01 = msg.cERROR_Colon + wrd.cFailure + bas.cSpace + wrd.cto + bas.cSpace + wrd.cwrite + bas.cSpace + wrd.cout + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cfile + bas.cColon + bas.cSpace; // ERROR: Failure to write out the file:
// WARNING: You are not allowed to run this lesson,
export const cWarningStartLessonMessage01 = msg.cWARNING_Colon + wrd.cYou + bas.cSpace + wrd.care + bas.cSpace + wrd.cnot + bas.cSpace + wrd.callowed + bas.cSpace + wrd.cto + bas.cSpace + wrd.crun + bas.cSpace + wrd.cthis + bas.cSpace + wrd.clesson + bas.cComa;
// please complete the earlier lessons before proceeding.
export const cWarningStartLessonMessage02 = wrd.cplease + bas.cSpace + wrd.ccomplete + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cearlier + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cbefore + bas.cSpace + wrd.cproceeding + bas.cDot;
export const cgenerateUserReportMessage01 = wrd.cHaystacks + bas.cSpace + wrd.cTyping + bas.cSpace + wrd.cTutor + bas.cSpace + wrd.creport + bas.cSpace + wrd.ccard + bas.cSpace + wrd.cfor + bas.cSpace + wrd.cuser + bas.cColon + bas.cSpace; // Haystacks Typing Tutor report card for user:
export const cgenerateUserReportMessage02 = msg.cERROR_Colon + wrd.cUser + bas.cSpace + wrd.cis + bas.cSpace + wrd.cnot + bas.cSpace + wrd.clogged + bas.cSpace + wrd.cin + bas.cComa + bas.cSpace + wrd.ccannot + bas.cSpace + wrd.cgenerate + bas.cSpace + wrd.cuser + bas.cSpace + wrd.creport + bas.cDot; // ERROR: User is not logged in, cannot generate user report.
export const cgenerateUserReportMessage03 = wrd.cLogin + bas.cSpace + wrd.cto + bas.cSpace + wrd.can + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cand + bas.cSpace + wrd.ctry + bas.cSpace + wrd.cagain + bas.cDot; // Login to an account and try again.
export const cprintRecordsMessage01 = wrd.cHaystacks + bas.cSpace + wrd.cTyping + bas.cSpace + wrd.cTutor + bas.cSpace + wrd.cusers + bas.cSpace + wrd.creport + bas.cColon; // Haystacks Typing Tutor users report:
// ERROR: User must be logged in to set the current curriculum.
export const cErrorSetCurrentCurriculumMessage1 = msg.cERROR_Colon + wrd.cUser + bas.cSpace + wrd.cmust + bas.cSpace + wrd.cbe + bas.cSpace + wrd.clogged + bas.cSpace + wrd.cin + bas.cSpace + wrd.cto + bas.cSpace + wrd.cset + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ccurrent + bas.cSpace + wrd.ccurriculum + bas.cDot;
// ERROR: A name or index must be entered for the desired curriculum.
export const cErrorSetCurrentCurriculumMessage2 = msg.cERROR_Colon + bas.cA + bas.cSpace + wrd.cname + bas.cSpace + wrd.cor + bas.cSpace + wrd.cindex + bas.cSpace + wrd.cmust + bas.cSpace + wrd.cbe + bas.cSpace + wrd.centered + bas.cSpace + wrd.cfor + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cdesired + bas.cSpace + wrd.ccurriculum + bas.cDot;
// ERROR: fullyQualifiedCurriculumIndex is not valid.
export const cErrorSetCurrentCurriculumMessage3 = msg.cERROR_Colon + wrd.cfully + wrd.cQualified + wrd.cCurriculum + wrd.cIndex + bas.cSpace + wrd.cis + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cvalid + bas.cDot;
// ERROR: fullyQualifiedCurriculumName is not valid.
export const cErrorSetCurrentCurriculumMessage4 = msg.cERROR_Colon + wrd.cfully + wrd.cQualified + wrd.cCurriculum + wrd.cName + bas.cSpace + wrd.cis + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cvalid + bas.cDot;
// ERROR: User must be logged in to get the current curriculum.
export const cErrorGetCurrentCurriculumMessage1 = msg.cERROR_Colon + wrd.cUser + bas.cSpace + wrd.cmust + bas.cSpace + wrd.cbe + bas.cSpace + wrd.clogged + bas.cSpace + wrd.cin + bas.cSpace + wrd.cto + bas.cSpace + wrd.cget + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ccurrent + bas.cSpace + wrd.ccurriculum + bas.cDot;
// ERROR: No curriculumSearchTerm specified, unable to lookup Curriculum:
export const cErrorLookupCurriculumMessage1 = msg.cERROR_Colon + wrd.cNo + bas.cSpace + wrd.ccurriculum + wrd.cSearch + wrd.cTerm + bas.cSpace + wrd.cspecified + bas.cComa + bas.cSpace + wrd.cunable + bas.cSpace + wrd.cto + bas.cSpace + wrd.clookup + bas.cSpace + wrd.ccurriculum + bas.cColon + bas.cSpace;
// ERROR: curriculumSearchTerm is invalid: 
export const cErrorLookupCurriculumMessage2 = msg.cERROR_Colon + wrd.ccurriculum + wrd.cSearch + wrd.cTerm + bas.cSpace + wrd.cis + bas.cSpace + wrd.cinvalid + bas.cColon + bas.cSpace;
// ERROR: Invalid allCurriculumNames or curriculumIndices.
export const cErrorLookupCurriculumMessage3 = msg.cERROR_Colon + wrd.cInvalid + bas.cSpace + wrd.call + wrd.cCurriculum + wrd.cNames + bas.cSpace + wrd.cor + bas.cSpace + wrd.ccurriculum + wrd.cIndices + bas.cDot;
// ERROR: curriculumNamesArray was not valid, reference: getCurriculumNameFromIndex.
export const cErrorGetCurriculumNameFromIndexMessage1 = msg.cERROR_Colon + wrd.ccurriculum + wrd.cNames + wrd.cArray + bas.cSpace + wrd.cwas + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cvalid + bas.cComa + bas.cSpace + wrd.creference + bas.cColon + bas.cSpace + wrd.cget + wrd.cCurriculum + wrd.cName + wrd.cFrom + wrd.cIndex + bas.cDot;
export const cErrorSetEnableLessonPlanLimitingFactors1 = msg.cERROR_Colon + wrd.cSetting + bas.cSpace + wrd.cnot + bas.cSpace + wrd.csaved + bas.cColon + bas.cSpace; // ERROR: Setting not saved: 
export const cErrorSetEnableLessonPlanLimitingFactors2 = msg.cERROR_Colon + wrd.cInvalid + bas.cSpace + wrd.csetting + bas.cSpace + wrd.cvalue + bas.cSpace + wrd.cinput + bas.cDot + bas.cSpace + wrd.cSetting + bas.cColon + bas.cSpace; // ERROR: Invalid setting value input. Setting:
export const cWeFoundMatchingUserAccount = wrd.cWe + bas.cSpace + wrd.cfound + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cmatching + bas.cSpace + wrd.cuser + bas.cSpace + wrd.caccount + bas.cDot; // We found the matching user account.
export const cWeFoundMatchingCurriculumIndex = wrd.cWe + bas.cSpace + wrd.cfound + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cmatching + bas.cSpace + wrd.ccurriculum + bas.cSpace + wrd.cindex + bas.cDot; // We found the matching curriculum Index.
export const cWeFoundMatchingLessonName = wrd.cWe + bas.cSpace + wrd.cfound + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cmatching + bas.cSpace + wrd.clesson + wrd.cName + bas.cDot; // We found the matching lessonName.
// Determine if the user has completed the necessary prerequisite lessons and curriculums.
export const csetCurrentCurriculumMessage1 = wrd.cDetermine + bas.cSpace + wrd.cif + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cuser + bas.cSpace + wrd.chas + bas.cSpace + wrd.ccompleted + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cnecessary + bas.cSpace + wrd.cprerequisite + bas.cSpace + wrd.clessons + bas.cSpace + wrd.cand + bas.cSpace + wrd.ccurriculums + bas.cDot;
// allCurriculumNames and allCurriculumIndices is valid.
export const clookupCurriculumMessage1 = wrd.call + wrd.cCurriculum + wrd.cNames + bas.cSpace + wrd.cand + bas.cSpace + wrd.call + wrd.cCurriculum + wrd.cIndices + bas.cSpace + wrd.cis + bas.cSpace + wrd.cvalid + bas.cDot;
// curriculumSearchTerm is an integer.
export const clookupCurriculumMessage2 = wrd.ccurriculum + wrd.cSearch + wrd.cTerm + bas.cSpace + wrd.cis + bas.cSpace + wrd.can + bas.cSpace + wrd.cinteger + bas.cDot
// found a matching search index.
export const clookupCurriculumMessage3 = wrd.cfound + bas.cSpace + bas.ca + bas.cSpace + wrd.cmatching + bas.cSpace + wrd.csearch + bas.cSpace + wrd.cindex + bas.cDot;
// curriculumSearchTerm is a string.
export const clookupCurriculumMessage4 = wrd.ccurriculum + wrd.cSearch + wrd.cTerm + bas.cSpace + wrd.cis + bas.cSpace + bas.ca + bas.cSpace + wrd.cstring + bas.cDot;
// found a matching search term.
export const clookupCurriculumMessage5 = wrd.cfound + bas.cSpace + bas.ca + bas.cSpace + wrd.cmatching + bas.cSpace + wrd.csearch + bas.cSpace + wrd.cterm + bas.cDot;
// Incrementing the parsedCurriculumIndex, stage it for return and continue the loop.
export const cscanUserDataForCurrentCurriculumMessage1 = wrd.cIncrementing + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cparsed + wrd.cCurriculum + wrd.cIndex + bas.cComa + bas.cSpace + wrd.cstage + bas.cSpace + wrd.cit + bas.cSpace + wrd.cfor + bas.cSpace + wrd.creturn + bas.cSpace + wrd.cand + bas.cSpace + wrd.ccontinue + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cloop + bas.cDot;
// WARNING: parsedCurriculumIndex is not supported:
export const cWarningScanUserDataForCurrentCurriculumMessage1 = msg.cWARNING_Colon + wrd.cparsed + wrd.cCurriculum + wrd.cIndex + bas.cSpace + wrd.cis + bas.cSpace + wrd.cnot + bas.cSpace + wrd.csupported + bas.cColon + bas.cSpace;
// WARNING: UsersLessonDataValue is an empty array, return false from function: 
export const cWarningGetHighestScoringDataObjectForLessonMessage1 = msg.cWARNING_Colon + wrd.cUsers + wrd.cLesson + wrd.cData + wrd.cValue + bas.cSpace + wrd.cis + bas.cSpace + wrd.can + bas.cSpace + wrd.cempty + bas.cSpace + wrd.carray + bas.cComa + bas.cSpace + wrd.creturn + bas.cSpace + gen.cfalse + bas.cSpace + wrd.cfrom + bas.cSpace + wrd.cfunction + bas.cColon + bas.cSpace;
// WARNING: individualLessonName not found:
export const cWarningGetHighestScoringDataObjectForLessonMessage2 = msg.cWARNING_Colon + wrd.cindividual + wrd.cLesson + wrd.cName + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cfound + bas.cColon + bas.cSpace
// Found a false or empty lesson, break out of the loop and return that last known good returnData value.
export const cgetHighestLessonNumberAboveAdvancementScoringLimitMessage1 = wrd.cFound + bas.cSpace + bas.ca + bas.cSpace + gen.cfalse + bas.cSpace + wrd.cor + bas.cSpace + wrd.cempty + bas.cSpace + wrd.clesson + bas.cComa + bas.cSpace + wrd.cbreak + bas.cSpace + wrd.cout + bas.cSpace + wrd.cof + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cloop + bas.cSpace + wrd.cand + bas.cSpace + wrd.creturn + bas.cSpace + wrd.cthat + bas.cSpace + wrd.clast + bas.cSpace + wrd.cknown + bas.cSpace + wrd.cgood + bas.cSpace + sys.creturnData + bas.cSpace + wrd.cvalue + bas.cDot;
// ****************************************************************************************************
// Pass-Fail user messages
export const cLessonPassedMessage = wrd.cYou + bas.cSpace + wrd.cPASSED + bas.cExclamation + bas.cSpace + wrd.cYAY + bas.cExclamation.repeat(2); // You PASSED! YAY!!
// You did not get a passing score, please try the lesson again. Practice makes perfect!
export const cLessonNotPassedMessage = wrd.cYou + bas.cSpace + wrd.cdid + bas.cSpace + wrd.cnot + bas.cSpace + wrd.cget + bas.cSpace + bas.ca + bas.cSpace + wrd.cpassing + bas.cSpace + wrd.cscore + bas.cComa + bas.cSpace + wrd.cplease + bas.cSpace + wrd.ctry + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cagain + bas.cDot + bas.cSpace + wrd.cPractice + bas.cSpace + wrd.cmakes + bas.cSpace + wrd.cperfect + bas.cExclamation;
export const cLessonAccuracyGoodMessage = wrd.cYour + bas.cSpace + wrd.caccuracy + bas.cSpace + wrd.cis + bas.cSpace + wrd.cgood + bas.cDot; // Your accuracy is good.
// You need to improve your accuracy, make sure you go slow at first and get each key exactly correct.
export const cLessonImproveAccuracyMessage = wrd.cYou + bas.cSpace + wrd.cneed + bas.cSpace + wrd.cto + bas.cSpace + wrd.cimprove + bas.cSpace + wrd.cyour + bas.cSpace + wrd.caccuracy + bas.cComa + bas.cSpace + wrd.cmake + bas.cSpace + wrd.csure + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cgo + bas.cSpace + wrd.cslow + bas.cSpace + wrd.cat + bas.cSpace + num.cfirst + bas.cSpace + wrd.cand + bas.cSpace + wrd.cget + bas.cSpace + wrd.ceach + bas.cSpace + wrd.ckey + bas.cSpace + wrd.cexactly + bas.cSpace + wrd.ccorrect + bas.cDot;
export const cLessonSpeedGoodMessage = wrd.cYour + bas.cSpace + wrd.cspeed + bas.cSpace + wrd.cis + bas.cSpace + wrd.cgood + bas.cDot; // Your speed is good.
// You need to improve your speed, it might take many times through a lesson before you gain the confidence to type fast.
export const cLessonImproveSpeedMessage = wrd.cYou + bas.cSpace + wrd.cneed + bas.cSpace + wrd.cto + bas.cSpace + wrd.cimprove + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cspeed + bas.cComa + bas.cSpace + wrd.cit + bas.cSpace + wrd.cmight + bas.cSpace + wrd.ctake + bas.cSpace + wrd.cmany + bas.cSpace + wrd.ctimes + bas.cSpace + wrd.cthrough + bas.cSpace + bas.ca + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cbefore + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cgain + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cconfidence + bas.cSpace + wrd.cto + bas.cSpace + wrd.ctype + bas.cSpace + wrd.cfast + bas.cDot;

export const cmessageLessonTimeStampIs = wrd.cLesson + bas.cSpace + wrd.ctime + bas.cSpace + wrd.cstamp + sys.cSpaceIsColonSpace; // Lesson time stamp is:
export const cmessageTotalTimeIs = wrd.cTotal + bas.cSpace + wrd.ctime + sys.cSpaceIsColonSpace; // Total time is:
export const cmessageTotalCorrectCharacterCountIs = wrd.cTotal + bas.cSpace + wrd.ccorrect + bas.cSpace + wrd.ccharacter + bas.cSpace + wrd.ccount + sys.cSpaceIsColonSpace; // Total correct character count is:
export const cmessageTotalIncorrectCharacterCountIs = wrd.cTotal + bas.cSpace + wrd.cincorrect + bas.cSpace + wrd.ccharacter + bas.cSpace + wrd.ccount + sys.cSpaceIsColonSpace; // Total incorrect character count is:
export const cmessageTotalWordsIs = wrd.cTotal + bas.cSpace + wrd.cwords + sys.cSpaceIsColonSpace; // Total words is:
export const cmessageAverageWpmIs = wrd.cAverage + bas.cSpace + gen.cWPM + sys.cSpaceIsColonSpace; // Average WPM is:
export const cmessageAverageAccuracyIs = wrd.cAverage + bas.cSpace + wrd.caccuracy + sys.cSpaceIsColonSpace; // Average accuracy is:
export const cmessageAdjustedWpmIs = wrd.cAdjusted + bas.cSpace + gen.cWPM + sys.cSpaceIsColonSpace; // Adjusted WPM is:
// ****************************************************************************************************
// LESSON INSTRUCTIONS:
export const cLessonInstructionsMessage01 = wrd.cLESSON + bas.cSpace + wrd.cINSTRUCTIONS + bas.cColon;
// Place your left index finger on the "F" key, and your right index finger on the "J" key.
export const cLessonInstructionsMessage02 = wrd.cPlace + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cleft + bas.cSpace + wrd.cindex + bas.cSpace + wrd.cfinger + bas.cSpace + bas.con + bas.cSpace + wrd.cthe + bas.cSpace + bas.cDoubleQuote + bas.cF + bas.cDoubleQuote + bas.cSpace + wrd.ckey + bas.cComa + bas.cSpace + wrd.cand + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cright + bas.cSpace + wrd.cindex + bas.cSpace + wrd.cfinger + bas.cSpace + bas.con + bas.cSpace + wrd.cthe + bas.cSpace + bas.cDoubleQuote + bas.cJ + bas.cDoubleQuote + bas.cSpace + wrd.ckey + bas.cDot;
// Feel for the small raised bumps on the keys.
export const cLessonInstructionsMessage03 = wrd.cFeel + bas.cSpace + wrd.cfor + bas.cSpace + wrd.cthe + bas.cSpace + wrd.csmall + bas.cSpace + wrd.craised + bas.cSpace + wrd.cbumps + bas.cSpace + bas.con + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ckeys + bas.cDot;
// These will help you ensure your fingers are on the correct home row before you begin typing.
export const cLessonInstructionsMessage04 = wrd.cThese + bas.cSpace + wrd.cwill + bas.cSpace + wrd.chelp + bas.cSpace + wrd.cyou + bas.cSpace + wrd.censure + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cfingers + bas.cSpace + wrd.care + bas.cSpace + bas.con + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ccorrect + bas.cSpace + wrd.chome + bas.cSpace + wrd.crow + bas.cSpace + wrd.cbefore + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cbegin + bas.cSpace + wrd.ctyping + bas.cDot;
// The rest of your fingers should naturally fall to the 3 keys adjacent and inline on the same row.
export const cLessonInstructionsMessage05 = wrd.cThe + bas.cSpace + wrd.crest + bas.cSpace + wrd.cof + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cfingers + bas.cSpace + wrd.cshould + bas.cSpace + wrd.cnaturally + bas.cSpace + wrd.cfall + bas.cSpace + wrd.cto + bas.cSpace + wrd.cthe + bas.cSpace + num.c3 + bas.cSpace + wrd.ckeys + bas.cSpace + wrd.cadjacent + bas.cSpace + wrd.cand + bas.cSpace + wrd.cinline + bas.cSpace + bas.con + bas.cSpace + wrd.cthe + bas.cSpace + wrd.csame + bas.cSpace + wrd.crow + bas.cDot;
// Left fingers should rest on the keys "D", "S", and "A".
export const cLessonInstructionsMessage06 = wrd.cLeft + bas.cSpace + wrd.cfingers + bas.cSpace + wrd.cshould + bas.cSpace + wrd.crest + bas.cSpace + bas.con + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ckeys + bas.cSpace + bas.cDoubleQuote + bas.cD + bas.cDoubleQuote + bas.cComa + bas.cSpace + bas.cDoubleQuote + bas.cS + bas.cDoubleQuote + bas.cComa + bas.cSpace + wrd.cand + bas.cSpace + bas.cDoubleQuote + bas.cA + bas.cDoubleQuote + bas.cDot;
// Right fingers should rest on the keys "K", "L", and ";".
export const cLessonInstructionsMessage07 = wrd.cRight + bas.cSpace + wrd.cfingers + bas.cSpace + wrd.cshould + bas.cSpace + wrd.crest + bas.cSpace + bas.con + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ckeys + bas.cSpace + bas.cDoubleQuote + bas.cK + bas.cDoubleQuote + bas.cComa + bas.cSpace + bas.cDoubleQuote + bas.cL + bas.cDoubleQuote + bas.cComa + bas.cSpace + wrd.cand + bas.cSpace + bas.cDoubleQuote + bas.cSemiColon + bas.cDoubleQuote + bas.cDot;
// Sit upright in your chair, back straight, elbows at your sides.
export const cLessonInstructionsMessage08 = wrd.cSit + bas.cSpace + wrd.cupright + bas.cSpace + wrd.cin + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cchair + bas.cComa + bas.cSpace + wrd.cback + bas.cSpace + wrd.cstraight + bas.cComa + bas.cSpace + wrd.celbows + bas.cSpace + wrd.cat + bas.cSpace + wrd.cyour + bas.cSpace + wrd.csides + bas.cDot;
// The lesson will begin when you type the first character for each line.
export const cLessonInstructionsMessage09 = wrd.cThe + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cbegin + bas.cSpace + wrd.cwhen + bas.cSpace + wrd.cyou + bas.cSpace + wrd.ctype + bas.cSpace + wrd.cthe + bas.cSpace + num.cfirst + bas.cSpace + wrd.ccharacter + bas.cSpace + wrd.cfor + bas.cSpace + wrd.ceach + bas.cSpace + wrd.cline + bas.cDot;
// This is a timed lesson, so the faster you go the better your score will be.
export const cLessonInstructionsMessage10 = wrd.cThis + bas.cSpace + wrd.cis + bas.cSpace + bas.ca + bas.cSpace + wrd.ctimed + bas.cSpace + wrd.clesson + bas.cComa + bas.cSpace + wrd.cso + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cfaster + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cgo + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cbetter + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cscore + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cbe + bas.cDot;
// However, typing errors count against your score.
export const cLessonInstructionsMessage11 = wrd.cHowever + bas.cComa + bas.cSpace + wrd.ctyping + bas.cSpace + wrd.cerrors + bas.cSpace + wrd.ccount + bas.cSpace + wrd.cagainst + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cscore + bas.cDot;
// You must get an accuracy score of:
export const cLessonInstructionsMessage12 = wrd.cYou + bas.cSpace + wrd.cmust + bas.cSpace + wrd.cget + bas.cSpace + bas.can + bas.cSpace + wrd.caccuracy + bas.cSpace + wrd.cscore + bas.cSpace + wrd.cof + bas.cColon + bas.cSpace;
// And a speed score of at least:
export const cLessonInstructionsMessage13 = wrd.cAnd + bas.cSpace + bas.ca + bas.cSpace + wrd.cspeed + bas.cSpace + wrd.cscore + bas.cSpace + wrd.cof + bas.cSpace + wrd.cat + bas.cSpace + wrd.cleast + bas.cColon + bas.cSpace;
// or higher to advance to the next lesson.
export const cLessonInstructionsMessage14 = wrd.cor + bas.cSpace + wrd.chigher + bas.cSpace + wrd.cto + bas.cSpace + wrd.cadvance + bas.cSpace + wrd.cto + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cnext + bas.cSpace + wrd.clesson + bas.cDot;
// A report showing your score will display after the lesson is complete.
export const cLessonInstructionsMessage15 = bas.cA + bas.cSpace + wrd.creport + bas.cSpace + wrd.cshowing + bas.cSpace + wrd.cyour + bas.cSpace + wrd.cscore + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cdisplay + bas.cSpace + wrd.cafter + bas.cSpace + wrd.cthe + bas.cSpace + wrd.clesson + bas.cSpace + wrd.cis + bas.cSpace + wrd.ccomplete + bas.cDot;
// Press the "ESC" key, in the far upper left corner of the keyboard to cancel a lesson.
export const cLessonInstructionsMessage16 = wrd.cPress + bas.cSpace + wrd.cthe + bas.cSpace + bas.cDoubleQuote + gen.cESC + bas.cDoubleQuote + bas.cSpace + wrd.ckey + bas.cComa + bas.cSpace + wrd.cin + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cfar + bas.cSpace + wrd.cupper + bas.cSpace + wrd.cleft + bas.cSpace + wrd.ccorner + bas.cSpace + wrd.cof + bas.cSpace + wrd.cthe + bas.cSpace + wrd.ckeyboard + bas.cSpace + wrd.cto + bas.cSpace + wrd.ccancel + bas.cSpace + bas.ca + bas.cSpace + wrd.clesson + bas.cDot;
// ****************************************************************************************************
// Destroy Records Instructions
// Before you destroy the records, make sure you exit the Haystacks Typing Tutor application,
export const destroyRecordsInstructionsMessage01 = wrd.cBefore + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cdestroy + bas.cSpace + wrd.cthe + bas.cSpace + wrd.crecords + bas.cComa + bas.cSpace + wrd.cmake + bas.cSpace + wrd.csure + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cexit + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cHaystacks + bas.cSpace + wrd.cTyping + bas.cSpace + wrd.cTutor + bas.cSpace + wrd.capplication + bas.cComa;
// or the records will be resaved after you delete them.
export const destroyRecordsInstructionsMessage02 = wrd.cor + bas.cSpace + wrd.cthe + bas.cSpace + wrd.crecords + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cbe + bas.cSpace + wrd.cresaved + bas.cSpace + wrd.cafter + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cdelete + bas.cSpace + wrd.cthem + bas.cDot;
// You can destroy all records by going to the application installed path:
export const destroyRecordsInstructionsMessage03 = wrd.cYou + bas.cSpace + wrd.ccan + bas.cSpace + wrd.cdestroy + bas.cSpace + wrd.call + bas.cSpace + wrd.crecords + bas.cSpace + wrd.cby + bas.cSpace + wrd.cgoing + bas.cSpace + wrd.cto + bas.cSpace + wrd.cthe + bas.cSpace + wrd.capplication + bas.cSpace + wrd.cinstalled + bas.cSpace + wrd.cpath + bas.cColon;
// ./src/resources/accounts/
export const destroyRecordsInstructionsMessage04 = bas.cDot + apc.cFullDevAccountsPath;
// ./bin/resources/accounts/
export const destroyRecordsInstructionsMessage05 = bas.cDot + apc.cFullProdAccountsPath;
// Then delete all of the files with the .JSON file extension.
export const destroyRecordsInstructionsMessage06 = wrd.cThen + bas.cSpace + wrd.cdelete + bas.cSpace + wrd.call + bas.cSpace + wrd.cof + bas.cSpace + wrd.cthe + bas.cSpace + wrd.cfiles + bas.cSpace + wrd.cwith + bas.cSpace + wrd.cthe + bas.cSpace + gen.cDotJSON + bas.cSpace + wrd.cfile + bas.cSpace + wrd.cextension + bas.cDot;
// This will remove all account data from the system forever.
export const destroyRecordsInstructionsMessage07 = wrd.cThis + bas.cSpace + wrd.cwill + bas.cSpace + wrd.cremove + bas.cSpace + wrd.call + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cdata + bas.cSpace + wrd.cfrom + bas.cSpace + wrd.cthe + bas.cSpace + wrd.csystem + bas.cSpace + wrd.cforever + bas.cDot;
// If you wish to back-up the account data,
export const destroyRecordsInstructionsMessage08 = wrd.cIf + bas.cSpace + wrd.cyou + bas.cSpace + wrd.cwish + bas.cSpace + wrd.cto + bas.cSpace + wrd.cback + bas.cDash + wrd.cup + bas.cSpace + wrd.cthe + bas.cSpace + wrd.caccount + bas.cSpace + wrd.cdata + bas.cComa;
// you can copy these files to another storage location before deleting them.
export const destroyRecordsInstructionsMessage09 = wrd.cyou + bas.cSpace + wrd.ccan + bas.cSpace + wrd.ccopy + bas.cSpace + wrd.cthese + bas.cSpace + wrd.cfiles + bas.cSpace + wrd.cto + bas.cSpace + wrd.canother + bas.cSpace + wrd.cstorage + bas.cSpace + wrd.clocation + bas.cSpace + wrd.cbefore + bas.cSpace + wrd.cdeleting + bas.cSpace + wrd.cthem + bas.cDot;
// ****************************************************************************************************
// ASCII Keyboard map art:
// ****************************************************************************************************
// .--------------------------------------------------------------------.
// | [ESC] [F1][F2][F3][F4][F5][F6][F7][F8][F9][F0][F10][F11][F12] o o o|
// |                                                                    |
// | [`][1][2][3][4][5][6][7][8][9][0][-][=][_<_] [I][H][U] [N][/][*][-]|
// | [/T][Q][W][E][R][T][Y][U][I][O][P][{][}] | | [D][E][D] [7][8][9]|+||
// | [CAP][A][S][D][F][G][H][J][K][L][;]['][_<-_]           [4][5][6]|_||
// | [SHIFT][Z][X][C][V][B][N][M][,][.][/][SHIFT]    [^]    [1][2][3]| ||
// | [CTRL][ALT][_______SPACE________][ALT][CTRL] [<][V][>] [ 0  ][.]|_||
// `--------------------------------------------------------------------'
// ****************************************************************************************************
// .--------------------------------------------------------------------.
export const cKeyboardAsciMap01 = bas.cDot + bas.cDoubleDash.repeat(34) + bas.cDot;
// | [ESC] [F1][F2][F3][F4][F5][F6][F7][F8][F9][F0][F10][F11][F12] o o o|
export const cKeyboardAsciMap02 = bas.cPipe + bas.cSpace + bas.cOpenBracket + gen.cESC + bas.cCloseBracket + bas.cSpace +
bas.cOpenBracket + bas.cF + num.c1 + bas.cCloseBracket + 
bas.cOpenBracket + bas.cF + num.c2 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c3 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c4 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c5 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c6 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c7 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c8 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c9 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c10 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c11 + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + num.c12 + bas.cCloseBracket + bas.cSpace + bas.co + bas.cSpace + bas.co + bas.cSpace + bas.co + bas.cPipe;
// |                                                                    |
export const cKeyboardAsciMap03 = bas.cPipe + bas.cSpace.repeat(68) + bas.cPipe;
// | [`][1][2][3][4][5][6][7][8][9][0][-][=][_<_] [I][H][U] [N][/][*][-]|
export const cKeyboardAsciMap04 = bas.cPipe + bas.cSpace + 
bas.cOpenBracket + bas.cBackTickQuote + bas.cCloseBracket +
bas.cOpenBracket + num.c1 + bas.cCloseBracket +
bas.cOpenBracket + num.c2 + bas.cCloseBracket +
bas.cOpenBracket + num.c3 + bas.cCloseBracket +
bas.cOpenBracket + num.c4 + bas.cCloseBracket +
bas.cOpenBracket + num.c5 + bas.cCloseBracket +
bas.cOpenBracket + num.c6 + bas.cCloseBracket +
bas.cOpenBracket + num.c7 + bas.cCloseBracket +
bas.cOpenBracket + num.c8 + bas.cCloseBracket +
bas.cOpenBracket + num.c9 + bas.cCloseBracket +
bas.cOpenBracket + num.c0 + bas.cCloseBracket +
bas.cOpenBracket + bas.cDash + bas.cCloseBracket +
bas.cOpenBracket + bas.cEqual + bas.cCloseBracket +
bas.cOpenBracket + bas.cUnderscore + bas.cLessThan + bas.cUnderscore + bas.cCloseBracket + bas.cSpace +
bas.cOpenBracket + bas.cI + bas.cCloseBracket +
bas.cOpenBracket + bas.cH + bas.cCloseBracket +
bas.cOpenBracket + bas.cU + bas.cCloseBracket + bas.cSpace +
bas.cOpenBracket + bas.cN + bas.cCloseBracket +
bas.cOpenBracket + bas.cForwardSlash + bas.cCloseBracket +
bas.cOpenBracket + bas.cStar + bas.cCloseBracket +
bas.cOpenBracket + bas.cDash + bas.cCloseBracket + bas.cPipe;
// | [/T][Q][W][E][R][T][Y][U][I][O][P][{][}] | | [D][E][D] [7][8][9]|+||
export const cKeyboardAsciMap05 = bas.cPipe + bas.cSpace +
bas.cOpenBracket + bas.cForwardSlash + bas.cT + bas.cCloseBracket +
bas.cOpenBracket + bas.cQ + bas.cCloseBracket +
bas.cOpenBracket + bas.cW + bas.cCloseBracket +
bas.cOpenBracket + bas.cE + bas.cCloseBracket +
bas.cOpenBracket + bas.cR + bas.cCloseBracket +
bas.cOpenBracket + bas.cT + bas.cCloseBracket +
bas.cOpenBracket + bas.cY + bas.cCloseBracket +
bas.cOpenBracket + bas.cU + bas.cCloseBracket +
bas.cOpenBracket + bas.cI + bas.cCloseBracket +
bas.cOpenBracket + bas.cO + bas.cCloseBracket +
bas.cOpenBracket + bas.cP + bas.cCloseBracket +
bas.cOpenBracket + bas.cOpenCurlyBrace + bas.cCloseBracket +
bas.cOpenBracket + bas.cCloseCurlyBrace + bas.cCloseBracket + bas.cSpace + bas.cPipe + bas.cSpace + bas.cPipe + bas.cSpace +
bas.cOpenBracket + bas.cD + bas.cCloseBracket +
bas.cOpenBracket + bas.cE + bas.cCloseBracket +
bas.cOpenBracket + bas.cD + bas.cCloseBracket + bas.cSpace +
bas.cOpenBracket + num.c7 + bas.cCloseBracket + 
bas.cOpenBracket + num.c8 + bas.cCloseBracket +
bas.cOpenBracket + num.c9 + bas.cCloseBracket + bas.cPipe + bas.cPlus + bas.cDoublePipe;
// | [CAP][A][S][D][F][G][H][J][K][L][;]['][_<-_]           [4][5][6]|_||
export const cKeyboardAsciMap06 = bas.cPipe + bas.cSpace +
bas.cOpenBracket + bas.cCA + bas.cP + bas.cCloseBracket +
bas.cOpenBracket + bas.cA + bas.cCloseBracket +
bas.cOpenBracket + bas.cS + bas.cCloseBracket +
bas.cOpenBracket + bas.cD + bas.cCloseBracket +
bas.cOpenBracket + bas.cF + bas.cCloseBracket +
bas.cOpenBracket + bas.cG + bas.cCloseBracket +
bas.cOpenBracket + bas.cH + bas.cCloseBracket +
bas.cOpenBracket + bas.cJ + bas.cCloseBracket +
bas.cOpenBracket + bas.cK + bas.cCloseBracket +
bas.cOpenBracket + bas.cL + bas.cCloseBracket +
bas.cOpenBracket + bas.cSemiColon + bas.cCloseBracket +
bas.cOpenBracket + bas.cSingleQuote + bas.cCloseBracket +
bas.cOpenBracket + bas.cUnderscore + bas.cLessThan + bas.cDash + bas.cUnderscore + bas.cCloseBracket + bas.cSpace.repeat(11) +
bas.cOpenBracket + num.c4 + bas.cCloseBracket +
bas.cOpenBracket + num.c5 + bas.cCloseBracket +
bas.cOpenBracket + num.c6 + bas.cCloseBracket + bas.cPipe + bas.cUnderscore + bas.cDoublePipe;
// | [SHIFT][Z][X][C][V][B][N][M][,][.][/][SHIFT]    [^]    [1][2][3]| ||
export const cKeyboardAsciMap07 = bas.cPipe + bas.cSpace +
bas.cOpenBracket + gen.cSHIFT + bas.cCloseBracket +
bas.cOpenBracket + bas.cZ + bas.cCloseBracket +
bas.cOpenBracket + bas.cX + bas.cCloseBracket +
bas.cOpenBracket + bas.cC + bas.cCloseBracket +
bas.cOpenBracket + bas.cV + bas.cCloseBracket +
bas.cOpenBracket + bas.cB + bas.cCloseBracket +
bas.cOpenBracket + bas.cN + bas.cCloseBracket +
bas.cOpenBracket + bas.cM + bas.cCloseBracket +
bas.cOpenBracket + bas.cComa + bas.cCloseBracket +
bas.cOpenBracket + bas.cDot + bas.cCloseBracket +
bas.cOpenBracket + bas.cForwardSlash + bas.cCloseBracket +
bas.cOpenBracket + gen.cSHIFT + bas.cCloseBracket + bas.cSpace.repeat(4) +
bas.cOpenBracket + bas.cCarrot + bas.cCloseBracket + bas.cSpace.repeat(4) +
bas.cOpenBracket + num.c1 + bas.cCloseBracket +
bas.cOpenBracket + num.c2 + bas.cCloseBracket +
bas.cOpenBracket + num.c3 + bas.cCloseBracket + bas.cPipe + bas.cSpace + bas.cDoublePipe;
// | [CTRL][ALT][_______SPACE________][ALT][CTRL] [<][V][>] [ 0  ][.]|_||
export const cKeyboardAsciMap08 = bas.cPipe + bas.cSpace +
bas.cOpenBracket + gen.cCTRL + bas.cCloseBracket +
bas.cOpenBracket + gen.cALT + bas.cCloseBracket + 
bas.cOpenBracket + bas.cUnderscore.repeat(7) + gen.cSPACE + bas.cUnderscore.repeat(8) + bas.cCloseBracket +
bas.cOpenBracket + gen.cALT + bas.cCloseBracket +
bas.cOpenBracket + gen.cCTRL + bas.cCloseBracket + bas.cSpace +
bas.cOpenBracket + bas.cLessThan + bas.cCloseBracket +
bas.cOpenBracket + bas.cV + bas.cCloseBracket +
bas.cOpenBracket + bas.cGreaterThan + bas.cCloseBracket + bas.cSpace +
bas.cOpenBracket + bas.cSpace + num.c0 + bas.cSpace.repeat(2) + bas.cCloseBracket +
bas.cOpenBracket + bas.cDot + bas.cCloseBracket + bas.cPipe + bas.cUnderscore + bas.cDoublePipe;
// ****************************************************************************************************

// Constants Validation
export const callClientConstantsValidationDataIs = wrd.call + wrd.cClient + wrd.cConstants + wrd.cValidation + wrd.cData + sys.cSpaceIsColonSpace; // allClientConstantsValidationData is:
export const cresolvedConstantsPath_ApplicationBusinessIs = app_sys.cresolvedConstantsPath_Application + wrd.cBusiness + sys.cSpaceIsColonSpace; // resolvedConstantsPath_ApplicationBusiness is:
export const cresolvedConstantsPath_ApplicationCommandIs = app_sys.cresolvedConstantsPath_Application + wrd.cCommand + sys.cSpaceIsColonSpace; // resolvedConstantsPath_ApplicationCommand is:
export const cresolvedConstantsPath_ApplicationConfigurationIs = app_sys.cresolvedConstantsPath_Application + wrd.cConfiguration + sys.cSpaceIsColonSpace; // resolvedConstantsPath_ApplicationConfiguration is:
export const cresolvedConstantsPath_ApplicationConstantIs = app_sys.cresolvedConstantsPath_Application + wrd.cConstant + sys.cSpaceIsColonSpace; // resolvedConstantsPath_ApplicationConstant is:
export const cresolvedConstantsPath_ApplicationMessageIs = app_sys.cresolvedConstantsPath_Application + wrd.cMessage + sys.cSpaceIsColonSpace; // resolvedConstantsPath_ApplicationMessage is:
export const cresolvedConstantsPath_ApplicationSystemIs = app_sys.cresolvedConstantsPath_Application + wrd.cSystem + sys.cSpaceIsColonSpace; // resolvedConstantsPath_ApplicationSystem is:

export const cApplicationBusinessConstantsPhase1Validation = wrd.cApplication + bas.cSpace + wrd.cBusiness + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c1 + bas.cSpace + wrd.cValidation; // Application Business Constants Phase 1 Validation
export const cApplicationCommandConstantsPhase1Validation = wrd.cApplication + bas.cSpace + wrd.cCommand + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c1 + bas.cSpace + wrd.cValidation; // Application Command Constants Phase 1 Validation
export const cApplicationConfigurationConstantsPhase1Validation = wrd.cApplication + bas.cSpace + wrd.cConfiguration + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c1 + bas.cSpace + wrd.cValidation; // Application Configuration Constants Phase 1 Validation
export const cApplicationConstantsPhase1Validation = wrd.cApplication + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c1 + bas.cSpace + wrd.cValidation; // Application Constants Phase 1 Validation
export const cApplicationMessageConstantsPhase1Validation = wrd.cApplication + bas.cSpace + wrd.cMessage + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c1 + bas.cSpace + wrd.cValidation; // Application Message Constants Phase 1 Validation
export const cApplicationSystemConstantsPhase1Validation = wrd.cApplication + bas.cSpace + wrd.cSystem + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c1 + bas.cSpace + wrd.cValidation; // Application System Constants Phase 1 Validation

export const cApplicationBusinessConstantsPhase2Validation = wrd.cApplication + bas.cSpace + wrd.cBusiness + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c2 + bas.cSpace + wrd.cValidation; // Application Business Constants Phase 2 Validation
export const cApplicationCommandConstantsPhase2Validation = wrd.cApplication + bas.cSpace + wrd.cCommand + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c2 + bas.cSpace + wrd.cValidation; // Application Command Constants Phase 2 Validation
export const cApplicationConfigurationConstantsPhase2Validation = wrd.cApplication + bas.cSpace + wrd.cConfiguration + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c2 + bas.cSpace + wrd.cValidation; // Application Configuration Constants Phase 2 Validation
export const cApplicationConstantsPhase2Validation = wrd.cApplication + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c2 + bas.cSpace + wrd.cValidation; // Application Constants Phase 2 Validation
export const cApplicationMessageConstantsPhase2Validation = wrd.cApplication + bas.cSpace + wrd.cMessage + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c2 + bas.cSpace + wrd.cValidation; // Application Message Constants Phase 2 Validation
export const cApplicationSystemConstantsPhase2Validation = wrd.cApplication + bas.cSpace + wrd.cSystem + bas.cSpace + wrd.cConstants + bas.cSpace + wrd.cPhase + bas.cSpace + num.c2 + bas.cSpace + wrd.cValidation; // Application System Constants Phase 2 Validation

export const capplicationMessage01 = wrd.cBEGIN + bas.cSpace + wrd.cmain + bas.cSpace + wrd.cprogram + bas.cSpace + wrd.cloop; // BEGIN main program loop
export const capplicationMessage02 = wrd.cBEGIN + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cparser; // BEGIN command parser
export const capplicationMessage03 = wrd.cEND + bas.cSpace + wrd.ccommand + bas.cSpace + wrd.cparser; // END command parser
export const capplicationMessage04 = wrd.cEND + bas.cSpace + wrd.cmain + bas.cSpace + wrd.cprogram + bas.cSpace + wrd.cloop; // END main program loop
export const capplicationMessage05 = wrd.cExiting + bas.cSpace + wrd.cHaystacks + bas.cDash + bas.cTT + bas.cSpace + wrd.capplication; // Exiting Haystacks-TT application